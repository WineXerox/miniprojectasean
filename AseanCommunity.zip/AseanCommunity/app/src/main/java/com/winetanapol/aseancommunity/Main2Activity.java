package com.winetanapol.aseancommunity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    MediaPlayer click;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        click = MediaPlayer.create(Main2Activity.this,R.raw.sound);
        Button naxt1 = (Button) findViewById(R.id.btn01);
        naxt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Main2Activity.this ,Main3Activity.class);
                startActivity(i);

                click.start();
                finish();
            }
        });

        Button naxt2 = (Button) findViewById(R.id.btn02);
        naxt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Main2Activity.this ,Main4Activity.class);
                startActivity(i);

                click.start();
                finish();
            }
        });

        Button naxt3 = (Button) findViewById(R.id.btn03);
        naxt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Main2Activity.this ,Main5Activity.class);
                startActivity(i);

                click.start();
                finish();
            }
        });

    }
}
