package com.winetanapol.aseancommunity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public class Main5Activity extends AppCompatActivity {

    private void SenToIn(int food){

        String[] selected = {"อัมบูยัต",
                "อาม็อก",
                "ลักซา",
                "ต้มยำกุ้ง",
                "อโดโบ้",
                "หล่าเพ็ด",
                "นาซิ เลอมัก",
                "สลัดหลวงพระบาง",
                "กาโด กาโด",
                "ปอเปี๊ยะเวียดนาม"
        };

        Intent intent = new Intent(Main5Activity.this, ShowMain5.class);
        intent.putExtra("Food", selected[food]);
        startActivity(intent);
        finish();

        Toast toast = Toast.makeText(getApplicationContext(),
                selected[food],
                Toast.LENGTH_SHORT);
        toast.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setLayoutParams(linearParams);


        scrollView.addView(linearLayout);

        String[] ful = {"bn02","cbd02","sp02","th02","pp02","mm02","mls02","la02","ind02","vn02"};

        for(int i=0;i<ful.length;i++){

            ImageView imageView3 = new ImageView(this);
            LinearLayout.LayoutParams params3 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params3.setMargins(0, 30, 0, 30);
            params3.gravity = Gravity.CENTER;
            imageView3.setLayoutParams(params3);

            int id = getResources().getIdentifier(ful[i], "drawable", getPackageName());
            imageView3.setImageResource(id);
            linearLayout.addView(imageView3);

            final int finalI = i;
            imageView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SenToIn(finalI);
                }
            });
        }


        LinearLayout linearLayout3 = findViewById(R.id.rootContainer4);
        if (linearLayout3 != null) {
            linearLayout3.addView(scrollView);
        }
    }
}
