package com.winetanapol.aseancommunity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class ShowMain4 extends AppCompatActivity {

    MediaPlayer click;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_main4);

        click = MediaPlayer.create(ShowMain4.this,R.raw.sound);

        Intent intent = getIntent();
        String Thedress = intent.getStringExtra("Thedress");

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setLayoutParams(linearParams);


        scrollView.addView(linearLayout);



        ImageView imageView2 = new ImageView(this);
        LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params2.setMargins(0, 30, 0, 30);
        params2.gravity = Gravity.CENTER;
        imageView2.setLayoutParams(params2);

        TextView main4 = new TextView(this);
        LinearLayout.LayoutParams m4 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        m4.setMargins(60, 30, 50, 60);
        m4.gravity = Gravity.CENTER;
        main4.setTextColor(Color.DKGRAY);
        main4.setTextSize(18);
        main4.setLayoutParams(m4);

        TextView textView = new TextView(this);
        LinearLayout.LayoutParams text = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        text.setMargins(300, 30, 20, 30);
        textView.setTextColor(Color.DKGRAY);
        text.gravity = Gravity.CENTER;

        Button backmain4 = new Button(this);
        LinearLayout.LayoutParams back = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        back.setMargins(30, 100, 30, 30);
        back.gravity = Gravity.CENTER;
        backmain4.setText("ย้อนกลับ");
        backmain4.setTextSize(18);
        backmain4.setBackgroundResource(R.drawable.bg_btn_button);
        backmain4.setLayoutParams(back);
        backmain4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ShowMain4.this ,Main4Activity.class);
                startActivity(i);
                click.start();
                finish();
            }
        });

        if(Thedress.equals("บาจูมลายู&บาจูกุรุง")){
            imageView2.setImageResource(R.drawable.bn03);
            main4.setText(R.string.bn2);
        }
        if(Thedress.equals("ซัมปอต")){
            imageView2.setImageResource(R.drawable.cbd03);
            main4.setText(R.string.cbd2);
        }
        if(Thedress.equals("เกบาย่า")){
            imageView2.setImageResource(R.drawable.sp03);
            main4.setText(R.string.sp2);
        }
        if(Thedress.equals("ชุดไทยจักรี")){
            imageView2.setImageResource(R.drawable.th03);
            main4.setText(R.string.th2);
        }
        if(Thedress.equals("บารองตากาล็อก")){
            imageView2.setImageResource(R.drawable.pp03);
            main4.setText(R.string.pp2);
        }
        if(Thedress.equals("ลองยี")){
            imageView2.setImageResource(R.drawable.mm03);
            main4.setText(R.string.mm2);
        }
        if(Thedress.equals("บาจูมลายู บาจูกุรุง")){
            imageView2.setImageResource(R.drawable.mls03);
            main4.setText(R.string.mls2);
        }
        if(Thedress.equals("นุ่งผ้าซิ่น&นุ่งโจงกระเบน")){
            imageView2.setImageResource(R.drawable.la03);
            main4.setText(R.string.la2);
        }
        if(Thedress.equals("เกบาย่า&เตลุกเบสคาพ")){
            imageView2.setImageResource(R.drawable.ind03);
            main4.setText(R.string.ind2);
        }
        if(Thedress.equals("อ่าวหญ่าย")){
            imageView2.setImageResource(R.drawable.vn03);
            main4.setText(R.string.vn2);
        }

        linearLayout.addView(imageView2);
        linearLayout.addView(textView);
        linearLayout.addView(main4);
        linearLayout.addView(backmain4);


        textView.setText(Thedress);
        textView.setLayoutParams(text);





        LinearLayout linearLayout2 = findViewById(R.id.rootContainer3);
        if (linearLayout2 != null) {
            linearLayout2.addView(scrollView);
        }
    }
}
