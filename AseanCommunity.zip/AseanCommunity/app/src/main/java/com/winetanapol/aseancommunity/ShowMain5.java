package com.winetanapol.aseancommunity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class ShowMain5 extends AppCompatActivity {

    MediaPlayer click;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_main5);

        click = MediaPlayer.create(ShowMain5.this,R.raw.sound);

        Intent intent = getIntent();
        String food = intent.getStringExtra("Food");

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setLayoutParams(linearParams);


        scrollView.addView(linearLayout);



        ImageView imageView3 = new ImageView(this);
        LinearLayout.LayoutParams params3 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params3.setMargins(0, 30, 0, 30);
        params3.gravity = Gravity.CENTER;
        imageView3.setLayoutParams(params3);

        TextView main5 = new TextView(this);
        LinearLayout.LayoutParams m5 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        m5.setMargins(60, 30, 50, 60);
        m5.gravity = Gravity.CENTER;
        main5.setTextColor(Color.DKGRAY);
        main5.setTextSize(18);
        main5.setLayoutParams(m5);

        TextView textView = new TextView(this);
        LinearLayout.LayoutParams text = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        text.setMargins(300, 30, 0, 30);
        textView.setTextColor(Color.DKGRAY);
        text.gravity = Gravity.CENTER;

        Button backmain5 = new Button(this);
        LinearLayout.LayoutParams back = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        back.setMargins(25, 250, 30, 30);
        back.gravity = Gravity.CENTER;
        backmain5.setText("ย้อนกลับ");
        backmain5.setTextSize(18);
        backmain5.setBackgroundResource(R.drawable.bg_btn_button);
        backmain5.setLayoutParams(back);
        backmain5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ShowMain5.this ,Main5Activity.class);
                startActivity(i);
                click.start();
                finish();
            }
        });


        if(food.equals("อัมบูยัต")){
            imageView3.setImageResource(R.drawable.bn02);
            main5.setText(R.string.bn3);
        }
        if(food.equals("อาม็อก")){
            imageView3.setImageResource(R.drawable.cbd02);
            main5.setText(R.string.cbd3);
        }
        if(food.equals("ลักซา")){
            imageView3.setImageResource(R.drawable.sp02);
            main5.setText(R.string.sp3);
        }
        if(food.equals("ต้มยำกุ้ง")){
            imageView3.setImageResource(R.drawable.th02);
            main5.setText(R.string.th3);
        }
        if(food.equals("อโดโบ้")){
            imageView3.setImageResource(R.drawable.pp02);
            main5.setText(R.string.pp3);
        }
        if(food.equals("หล่าเพ็ด")){
            imageView3.setImageResource(R.drawable.mm02);
            main5.setText(R.string.mm3);
        }
        if(food.equals("นาซิ เลอมัก")){
            imageView3.setImageResource(R.drawable.mls02);
            main5.setText(R.string.mls3);
        }
        if(food.equals("สลัดหลวงพระบาง")){
            imageView3.setImageResource(R.drawable.la02);
            main5.setText(R.string.la3);
        }
        if(food.equals("กาโด กาโด")){
            imageView3.setImageResource(R.drawable.ind02);
            main5.setText(R.string.ind3);
        }
        if(food.equals("ปอเปี๊ยะเวียดนาม")){
            imageView3.setImageResource(R.drawable.vn02);
            main5.setText(R.string.vn3);
        }

        linearLayout.addView(imageView3);
        linearLayout.addView(textView);
        linearLayout.addView(main5);
        linearLayout.addView(backmain5);

        textView.setText(food);
        textView.setLayoutParams(text);





        LinearLayout linearLayout3 = findViewById(R.id.rootContainer4);
        if (linearLayout3 != null) {
            linearLayout3.addView(scrollView);
        }
    }
}
