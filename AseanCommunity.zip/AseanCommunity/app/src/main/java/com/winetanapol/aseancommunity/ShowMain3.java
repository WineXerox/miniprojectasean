package com.winetanapol.aseancommunity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class ShowMain3 extends AppCompatActivity {

    MediaPlayer click;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_main3);

        click = MediaPlayer.create(ShowMain3.this,R.raw.sound);

        Intent intent = getIntent();
        String Country = intent.getStringExtra("Country");

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setLayoutParams(linearParams);


        scrollView.addView(linearLayout);



        ImageView imageView1 = new ImageView(this);
        LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params1.setMargins(0, 30, 0, 30);
        params1.gravity = Gravity.CENTER;
        imageView1.setLayoutParams(params1);

        TextView main3 = new TextView(this);
        LinearLayout.LayoutParams m3 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        m3.setMargins(60, 30, 50, 60);
        m3.gravity = Gravity.CENTER;
        main3.setTextColor(Color.DKGRAY);
        main3.setTextSize(18);
        main3.setLayoutParams(m3);

        TextView textView = new TextView(this);
        LinearLayout.LayoutParams text = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        text.setMargins(300, 30, 20, 30);
        textView.setTextColor(Color.DKGRAY);
        text.gravity = Gravity.CENTER;

        Button backmain3 = new Button(this);
        LinearLayout.LayoutParams back = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        back.setMargins(30, 0, 30, 30);
        back.gravity = Gravity.CENTER;
        backmain3.setText("ย้อนกลับ");
        backmain3.setTextSize(18);
        backmain3.setBackgroundResource(R.drawable.bg_btn_button);
        backmain3.setLayoutParams(back);
        backmain3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ShowMain3.this ,Main3Activity.class);
                startActivity(i);

                click.start();
                finish();
            }
        });

        if(Country.equals("บรูไนดารุสซาลาม")){
            imageView1.setImageResource(R.drawable.bn01);
            main3.setText(R.string.bn1);
        }
        if(Country.equals("กัมพูชา")){
            imageView1.setImageResource(R.drawable.cbd01);
            main3.setText(R.string.cbd1);
        }
        if(Country.equals("สิงคโปร์")){
            imageView1.setImageResource(R.drawable.sp01);
            main3.setText(R.string.sp1);
        }
        if(Country.equals("ไทย")){
            imageView1.setImageResource(R.drawable.th01);
            main3.setText(R.string.th1);
        }
        if(Country.equals("ฟิลิปปินส์")){
            imageView1.setImageResource(R.drawable.pp01);
            main3.setText(R.string.pp1);
        }
        if(Country.equals("เมียนมาร์")){
            imageView1.setImageResource(R.drawable.mm01);
            main3.setText(R.string.mm1);
        }
        if(Country.equals("มาเลเซีย")){
            imageView1.setImageResource(R.drawable.mls01);
            main3.setText(R.string.mls1);
        }
        if(Country.equals("ลาว")){
            imageView1.setImageResource(R.drawable.la01);
            main3.setText(R.string.la1);
        }
        if(Country.equals("อินโดนีเซีย")){
            imageView1.setImageResource(R.drawable.ind01);
            main3.setText(R.string.ind1);
        }
        if(Country.equals("เวียดนาม")){
            imageView1.setImageResource(R.drawable.vn01);
            main3.setText(R.string.vn1);
        }

        linearLayout.addView(imageView1);
        linearLayout.addView(textView);
        linearLayout.addView(main3);
        linearLayout.addView(backmain3);


        textView.setText(Country);
        textView.setLayoutParams(text);





        LinearLayout linearLayout1 = findViewById(R.id.rootContainer2);
        if (linearLayout1 != null) {
            linearLayout1.addView(scrollView);
        }
    }
}
