package com.winetanapol.aseancommunity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {

    private void SenToIn(int country){

        String[] selected = {"บรูไนดารุสซาลาม",
                "กัมพูชา",
                "สิงคโปร์",
                "ไทย",
                "ฟิลิปปินส์",
                "เมียนมาร์",
                "มาเลเซีย",
                "ลาว",
                "อินโดนีเซีย",
                "เวียดนาม"
        };

        Intent intent = new Intent(Main3Activity.this, ShowMain3.class);
        intent.putExtra("Country", selected[country]);
        startActivity(intent);
        finish();

        Toast toast = Toast.makeText(getApplicationContext(),
                selected[country],
                Toast.LENGTH_SHORT);
        toast.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setLayoutParams(linearParams);


        scrollView.addView(linearLayout);

        String[] ful = {"bn01","cbd01","sp01","th01","pp01","mm01","mls01","la01","ind01","vn01"};

        for(int i=0;i<ful.length;i++){

            ImageView imageView1 = new ImageView(this);
            LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params1.setMargins(0, 30, 0, 30);
            params1.gravity = Gravity.CENTER;
            imageView1.setLayoutParams(params1);

            int id = getResources().getIdentifier(ful[i], "drawable", getPackageName());
            imageView1.setImageResource(id);
            linearLayout.addView(imageView1);

            final int finalI = i;
            imageView1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SenToIn(finalI);
                }
            });
        }


        LinearLayout linearLayout1 = findViewById(R.id.rootContainer);
        if (linearLayout1 != null) {
            linearLayout1.addView(scrollView);
        }
    }
}
