package com.winetanapol.aseancommunity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public class Main4Activity extends AppCompatActivity {

    private void SenToIn(int Thedress){

        String[] selected = {"บาจูมลายู&บาจูกุรุง",
                "ซัมปอต",
                "เกบาย่า",
                "ชุดไทยจักรี",
                "บารองตากาล็อก",
                "ลองยี",
                "บาจูมลายู บาจูกุรุง",
                "นุ่งผ้าซิ่น&นุ่งโจงกระเบน",
                "เกบาย่า&เตลุกเบสคาพ",
                "อ่าวหญ่าย"
        };

        Intent intent = new Intent(Main4Activity.this, ShowMain4.class);
        intent.putExtra("Thedress", selected[Thedress]);
        startActivity(intent);
        finish();

        Toast toast = Toast.makeText(getApplicationContext(),
                selected[Thedress],
                Toast.LENGTH_SHORT);
        toast.show();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setLayoutParams(linearParams);


        scrollView.addView(linearLayout);

        String[] ful = {"bn03","cbd03","sp03","th03","pp03","mm03","mls03","la03","ind03","vn03"};

        for(int i=0;i<ful.length;i++){

            ImageView imageView2 = new ImageView(this);
            LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params2.setMargins(0, 30, 0, 30);
            params2.gravity = Gravity.CENTER;
            imageView2.setLayoutParams(params2);

            int id = getResources().getIdentifier(ful[i], "drawable", getPackageName());
            imageView2.setImageResource(id);
            linearLayout.addView(imageView2);

            final int finalI = i;
            imageView2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SenToIn(finalI);
                }
            });
        }


        LinearLayout linearLayout2 = findViewById(R.id.rootContainer3);
        if (linearLayout2 != null) {
            linearLayout2.addView(scrollView);
        }
    }
}
